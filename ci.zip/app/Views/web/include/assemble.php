

<?= $this->include('web/include/header.php') ?>

<?= $this->renderSection('content'); ?>

<?= $this->include('web/include/footer.php') ?>